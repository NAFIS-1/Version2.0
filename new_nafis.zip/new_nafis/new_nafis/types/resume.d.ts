// types/resume.d.ts

// Interfaces for the frontend state management
export interface PersonalInfoState {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  location: string;
  title: string;
  summary: string;
  linkedin: string;
  website: string;
}

export interface WorkExperienceItem {
  id: number; // Added for React keys and easy removal
  title: string;
  company: string;
  location: string;
  startDate: string;
  endDate: string;
  current: boolean;
  description: string;
}

export interface EducationItem {
  id: number; // Added for React keys and easy removal
  degree: string;
  institution: string;
  location: string;
  startDate: string;
  endDate: string;
  description: string;
}

export interface SkillItem {
  id: number; // Added for React keys and easy removal
  name: string;
  level: any;
}

export interface LanguageItem {
  id: number; // Added for React keys and easy removal
  name: string;
  level: any;
}

// Interfaces for data coming from the backend (as provided by the user)
export interface BackendWorkExperience {
  jobTitle: string;
  company: string;
  location?: string | null;
  startDate: string;
  endDate: string;
  description?: string | null;
}

export interface BackendEducation {
  degreeCertification: string;
  institutionName: string;
  location: string;
  startYear: string;
  endYear: string;
  description: string;
}

export interface BackendLanguage {
  name: string;
  level: string;
}

export interface DeveloperData {
  firstName: string;
  lastName: string;
  professionalTitle: string;
  email: string;
  phone: string;
  location: string;
  linkedinURL: string | null;
  website: string;
  professionalSummary: string;
  workExperience: BackendWorkExperience[];
  education: BackendEducation[];
  skills: any[]; // Note: this is string[] from backend, will be converted to SkillItem[] for frontend
  languages: BackendLanguage[];
  certifications: string[];
}

// Combined interface for the full response from the backend
export interface ParsedResumeResponse {
  extractedData: DeveloperData;
  completenessPercentage: number;
  remainingFields:any[]
}
