"use client"

import { useState, useEffect } from "react";
import { Check, Download, Eye, FileText, LinkIcon, Loader2, Plus, Save, Share2, Trash2, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Switch } from "@/components/ui/switch";
import UploadCV from "@/components/UploadResume/Upload"; // Ensure this path is correct
import ProgressTracker from "@/components/UploadResume/ProgressTracker"; // Ensure this path is correct
import PreviewResume from "@/components/UploadResume/PreviewResume"; // Ensure this path is correct
import SelectPlan from "@/components/UploadResume/Steps/selectplan"; // Ensure this path is correct
import PersonalInfo from "@/components/UploadResume/Steps/PersonalInfo"; // Ensure this path is correct
import WorkExperience from "@/components/UploadResume/Steps/WorkExperience"; // Ensure this path is correct

// Import the newly created components
import EducationSection from "@/components/UploadResume/EducationSection";
import SkillsAndLanguagesSection from "@/components/UploadResume/SkillsAndLanguagesSection";
import TipsAndSuggestions from "@/components/UploadResume/Tipsandsuggestions";

// Import types
import {
  PersonalInfoState,
  WorkExperienceItem,
  EducationItem,
  SkillItem,
  LanguageItem,
  ParsedResumeResponse,
  DeveloperData,
  BackendWorkExperience,
  BackendEducation,
  BackendLanguage
} from "@/types/resume";

export default function CVBuilderPage() {
  const [activeStep, setActiveStep] = useState(1);
  const [progress, setProgress] = useState(20);
  const [selectedTemplate, setSelectedTemplate] = useState("professional");
  const [isLoading, setIsLoading] = useState(false);
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [data,setdata]=useState<ParsedResumeResponse>(
{
  "extractedData": {
    "firstName": "Aryan",
    "lastName": "Jain",
    "professionalTitle": "Backend Developer",
    "email": "jainaryanjain00@gmail.com",
    "phone": "+91 7579733133",
    "location": "Manipuri, Uttar Pradesh",
    "linkedinURL": null,
    "website": "https://aryanjainportfolio.netlify.app/",
    "professionalSummary": "Passionate Backend Developer with expertise in building scalable and secure systems. Seeking a challenging role to leverage my skills in Node.js, Express.js, and database management, while continuously learning and contributing to innovative solutions.",
    "workExperience": [
      {
        "jobTitle": "Fullstack developer trainee",
        "company": "Gradious Technologies",
        "location": null,
        "startDate": "24-03-2024",
        "endDate": "present",
        "description": null
      }
    ],
    "education": [
      {
        "degreeCertification": "12th (PCM)",
        "institutionName": "St. Thomas Sr. Sec School",
        "location": "Bhogao Road , Manipuri , Uttar Pradesh -205001",
        "startYear": "2020",
        "endYear": "2021",
        "description": "78%"
      },
      {
        "degreeCertification": "10th",
        "institutionName": "St. Thomas Sr. Sec School",
        "location": "Bhogao Road , Manipuri , Uttar Pradesh -205001",
        "startYear": "2018",
        "endYear": "2019",
        "description": "71%"
      }
    ],
    "skills": [
      {
        "name": "JavaScript",
        "level": "Beginner"
      },
      {
        "name": "React.js",
        "level": "Beginner"
      },
      {
        "name": "TypeScript",
        "level": "Beginner"
      },
      {
        "name": "Next.js",
        "level": "Beginner"
      },
      {
        "name": "Node.js",
        "level": "Beginner"
      },
      {
        "name": "MongoDB",
        "level": "Beginner"
      },
      {
        "name": "MySQL",
        "level": "Beginner"
      },
      {
        "name": "Java",
        "level": "Beginner"
      },
      {
        "name": "GraphQL",
        "level": "Beginner"
      },
      {
        "name": "gRPC",
        "level": "Beginner"
      },
      {
        "name": "Web Sockets",
        "level": "Beginner"
      },
      {
        "name": "GSAP",
        "level": "Beginner"
      },
      {
        "name": "Framer Motion",
        "level": "Beginner"
      },
      {
        "name": "Tailwind CSS",
        "level": "Beginner"
      },
      {
        "name": "Angular js",
        "level": "Beginner"
      },
      {
        "name": "HTML",
        "level": "Beginner"
      },
      {
        "name": "CSS",
        "level": "Beginner"
      },
      {
        "name": "Tailwind",
        "level": "Beginner"
      },
      {
        "name": "Express.js",
        "level": "Beginner"
      },
      {
        "name": "AsertinityUI",
        "level": "Beginner"
      },
      {
        "name": "ShadCN",
        "level": "Beginner"
      },
      {
        "name": "Material UI",
        "level": "Beginner"
      },
      {
        "name": "Kafka",
        "level": "Beginner"
      },
      {
        "name": "Redis Pub/Sub",
        "level": "Beginner"
      },
      {
        "name": "VS Code",
        "level": "Beginner"
      },
      {
        "name": "IntelliJ",
        "level": "Beginner"
      },
      {
        "name": "Eclipse",
        "level": "Beginner"
      },
      {
        "name": "NetBeans",
        "level": "Beginner"
      },
      {
        "name": "Canva",
        "level": "Beginner"
      }
    ],
    "languages": [
      {
        "name": "English",
        "level": "Beginner"
      },
      {
        "name": "Hindi",
        "level": "Beginner"
      }
    ],
    "certifications": [
      "Google Cloud Engineering-Certificate",
      "AWS Cloud Certification"
    ]
  },
  "completenessPercentage": 92,
  "remainingFields": [
    "linkedinURL"
  ]
}
  );
  const [uploadedData, setUploadedData] = useState<ParsedResumeResponse | null>(null); // State to hold data from upload

  const templates = [
    {
      id: "professional",
      name: "Professional",
      description: "Clean and corporate design suitable for traditional industries",
      thumbnail: "/placeholder.svg?height=120&width=90",
    },
    {
      id: "modern",
      name: "Modern",
      description: "Contemporary design with creative layout",
      thumbnail: "/placeholder.svg?height=120&width=90",
    },
    {
      id: "executive",
      name: "Executive",
      description: "Sophisticated design for senior positions",
      thumbnail: "/placeholder.svg?height=120&width=90",
    },
    {
      id: "creative",
      name: "Creative",
      description: "Bold design for creative industries",
      thumbnail: "/placeholder.svg?height=120&width=90",
    },
  ];

  const [personalInfo, setPersonalInfo] = useState<PersonalInfoState>({
    firstName: "Ahmed",
    lastName: "Al Mansouri",
    email: "ahmed.almansouri@example.com",
    phone: "+971 50 123 4567",
    location: "Dubai, UAE",
    title: "Senior Frontend Developer",
    summary:
      "Experienced Frontend Developer with 5+ years of expertise in building modern, responsive web applications. Proficient in React, JavaScript, and UI/UX design.",
    linkedin: "linkedin.com/in/ahmedalmansouri",
    website: "ahmedalmansouri.com",
  });

  const [workExperience, setWorkExperience] = useState<WorkExperienceItem[]>([
    {
      id: 1,
      title: "Senior Frontend Developer",
      company: "Emirates NBD",
      location: "Dubai, UAE",
      startDate: "2022-01",
      endDate: "Present",
      current: true,
      description:
        "Developing digital banking solutions using React and TypeScript. Leading a team of 3 developers and implementing best practices.",
    },
    {
      id: 2,
      title: "Frontend Developer",
      company: "Etisalat Digital",
      location: "Abu Dhabi, UAE",
      startDate: "2019-03",
      endDate: "2021-12",
      current: false,
      description:
        "Developed responsive web applications and mobile interfaces. Collaborated with UX designers to implement user-friendly interfaces.",
    },
  ]);

  const [education, setEducation] = useState<EducationItem[]>([
    {
      id: 1,
      degree: "Bachelor of Computer Science",
      institution: "United Arab Emirates University",
      location: "Al Ain, UAE",
      startDate: "2015",
      endDate: "2019",
      description: "Graduated with honors. Specialized in Software Engineering.",
    },
  ]);

  const [skills, setSkills] = useState<SkillItem[]>([
    { id: 1, name: "React", level: "Expert" },
    { id: 2, name: "JavaScript", level: "Expert" },
    { id: 3, name: "TypeScript", level: "Advanced" },
    { id: 4, name: "HTML/CSS", level: "Expert" },
    { id: 5, name: "Node.js", level: "Intermediate" },
    { id: 6, name: "UI/UX Design", level: "Advanced" },
  ]);

  const [languages, setLanguages] = useState<LanguageItem[]>([
    { id: 1, name: "Arabic", level: "Native" },
    { id: 2, name: "English", level: "Fluent" },
  ]);

  // Effect to update form fields when uploadedData changes
  useEffect(() => {
    if (uploadedData && uploadedData.extractedData) {
      const data = uploadedData.extractedData;

      // Update Personal Info
      setPersonalInfo({
        firstName: data.firstName || personalInfo.firstName,
        lastName: data.lastName || personalInfo.lastName,
        email: data.email || personalInfo.email,
        phone: data.phone || personalInfo.phone,
        location: data.location || personalInfo.location,
        title: data.professionalTitle || personalInfo.title,
        summary: data.professionalSummary || personalInfo.summary,
        linkedin: data.linkedinURL || personalInfo.linkedin,
        website: data.website || personalInfo.website,
      });

      // Update Work Experience
      const newWorkExperience: WorkExperienceItem[] = data.workExperience.map((exp: BackendWorkExperience, index) => ({
        id: Date.now() + index, // Generate unique ID
        title: exp.jobTitle || "",
        company: exp.company || "",
        location: exp.location || "",
        startDate: exp.startDate || "",
        endDate: exp.endDate || "",
        current: exp.endDate === "Present" || exp.endDate === "current", // Assuming "Present" or "current" means current job
        description: exp.description || "",
      }));
      setWorkExperience(newWorkExperience.length > 0 ? newWorkExperience : workExperience);


      // Update Education
      const newEducation: EducationItem[] = data.education.map((edu: BackendEducation, index) => ({
        id: Date.now() + index, // Generate unique ID
        degree: edu.degreeCertification || "",
        institution: edu.institutionName || "",
        location: edu.location || "",
        startDate: edu.startYear || "",
        endDate: edu.endYear || "",
        description: edu.description || "",
      }));
      setEducation(newEducation.length > 0 ? newEducation : education);

      // Update Skills (convert string[] to SkillItem[])
      const newSkills: SkillItem[] = data.skills.map((skillName: string, index) => ({
        id: Date.now() + index, // Generate unique ID
        name: skillName,
        level: "Intermediate", // Default level, can be adjusted if AI provides it
      }));
      setSkills(newSkills.length > 0 ? newSkills : skills);

      // Update Languages (convert BackendLanguage[] to LanguageItem[])
      const newLanguages: LanguageItem[] = data.languages.map((lang: BackendLanguage, index) => ({
        id: Date.now() + index, // Generate unique ID
        name: lang.name,
        level: lang.level as LanguageItem['level'] || "Fluent", // Cast to correct type, default if needed
      }));
      setLanguages(newLanguages.length > 0 ? newLanguages : languages);

      // Optionally, move to the first step after data is loaded
      setActiveStep(2); // Move to Personal Information after upload
      setProgress(40); // Update progress
    }
  }, [uploadedData]); // Dependency array: run when uploadedData changes

  const handleNextStep = () => {
    const nextStep = activeStep + 1;
    setActiveStep(nextStep);
    setProgress(nextStep * 20);
  };

  const handlePrevStep = () => {
    const prevStep = activeStep - 1;
    setActiveStep(prevStep);
    setProgress(prevStep * 20);
  };

  const handleAddWorkExperience = () => {
    setWorkExperience([
      ...workExperience,
      {
        id: Date.now(),
        title: "",
        company: "",
        location: "",
        startDate: "",
        endDate: "",
        current: false,
        description: "",
      },
    ]);
  };

  const handleRemoveWorkExperience = (id: number) => {
    setWorkExperience(workExperience.filter((exp) => exp.id !== id));
  };

  const handleAddEducation = () => {
    setEducation([
      ...education,
      {
        id: Date.now(),
        degree: "",
        institution: "",
        location: "",
        startDate: "",
        endDate: "",
        description: "",
      },
    ]);
  };

  const handleRemoveEducation = (id: number) => {
    setEducation(education.filter((edu) => edu.id !== id));
  };

  const handleAddSkill = () => {
    setSkills([...skills, { id: Date.now(), name: "", level: "Beginner" }]);
  };

  const handleRemoveSkill = (id: number) => {
    setSkills(skills.filter((skill) => skill.id !== id));
  };

  const handleAddLanguage = () => {
    setLanguages([...languages, { id: Date.now(), name: "", level: "Beginner" }]);
  };

  const handleRemoveLanguage = (id: number) => {
    setLanguages(languages.filter((lang) => lang.id !== id));
  };

  const handleGenerateCV = () => {
        setIsPreviewMode(true);

  };

  // Callbacks for UploadCV component
 const onUploadStart = () => {

  if (!data) return;

  // Update Personal Info
  setPersonalInfo((prev) => ({
    ...prev,
    firstName: data.extractedData.firstName || '',
    lastName: data.extractedData.lastName ||'',
    email: data.extractedData.email || '',
    phone: data.extractedData.phone || '',
    location: data.extractedData.location ||'',
    title: data.extractedData.professionalTitle || '',
    summary: data.extractedData.professionalSummary || '',
    linkedin: data.extractedData.linkedinURL || '',
    website: data.extractedData.website || '',
  }));

  // Update Work Experience
  if (data.extractedData.workExperience && data.extractedData.workExperience.length > 0) {
    const formattedWork = data.extractedData.workExperience.map((exp, index) => ({
      id: Date.now() + index,
      title: exp.jobTitle || "",
      company: exp.company || "",
      location: exp.location || "",
      startDate: exp.startDate || "",
      endDate: exp.endDate || "",
      current: exp.endDate?.toLowerCase() === "present" || exp.endDate?.toLowerCase() === "current",
      description: exp.description || "",
    }));
    setWorkExperience(formattedWork);
  }

  // Update Education
  if (data.extractedData.education && data.extractedData.education.length > 0) {
    const formattedEducation = data.extractedData.education.map((edu, index) => ({
      id: Date.now() + index,
      degree: edu.degreeCertification || "",
      institution: edu.institutionName || "",
      location: edu.location || "",
      startDate: edu.startYear || "",
      endDate: edu.endYear || "",
      description: edu.description || "",
    }));
    setEducation(formattedEducation);
  }

  // Update Skills
  if (data.extractedData.skills && data.extractedData.skills.length > 0) {
    const formattedSkills = data.extractedData.skills.map((skill, index) => ({
      id: Date.now() + index,
      name: skill.name,
      level: skill.level, // default level, since raw data doesn't include it
    }));
    setSkills(formattedSkills);
  }

  // Update Languages
  if (data.extractedData.languages && data.extractedData.languages.length > 0) {
    const formattedLanguages = data.extractedData.languages.map((lang, index) => ({
      id: Date.now() + index,
      name: lang.name || "",
      level: lang.level || "Fluent",
    }));
    setLanguages(formattedLanguages);
  }

  // Move to the next step automatically
  setActiveStep(activeStep);
  setProgress(progress);
  console.log("Resume data pre-filled from uploaded file:", data);
};


useEffect(()=>      onUploadStart()
,[data]);
  return (
    <div className="wrapper max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="heading-lg mb-1">CV Builder</h1>
          <p className="text-muted-foreground">Create a professional CV in minutes</p>
        </div>
        {/* Pass new callback props to UploadCV */}
        <UploadCV
          isLoading={isLoading}
          onUploadStart={onUploadStart}
          isPreviewMode={isPreviewMode}
          setIsPreviewMode={setIsPreviewMode} setdata={setdata}   />
      </div>

      {/* Progress Tracker */}
      <ProgressTracker progress={progress} activeStep={activeStep} />
      {isPreviewMode ? (
        <PreviewResume
          personalInfo={personalInfo}
          workExperience={workExperience}
          education={education}
          skills={skills}
          languages={languages}
          selectedTemplate={selectedTemplate}
          templates={templates}
          setSelectedTemplate={setSelectedTemplate}
          setIsPreviewMode={setIsPreviewMode}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>
                  {activeStep === 1
                    ? "Choose a Template"
                    : activeStep === 2
                    ? "Personal Information"
                    : activeStep === 3
                    ? "Work Experience"
                    : activeStep === 4
                    ? "Education"
                    : "Skills & Languages"}
                </CardTitle>
                <CardDescription>
                  {activeStep === 1
                    ? "Select a template for your CV"
                    : activeStep === 2
                    ? "Enter your personal details"
                    : activeStep === 3
                    ? "Add your work experience"
                    : activeStep === 4
                    ? "Add your education history"
                    : "Add your skills and languages"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {/* Step 1: Template Selection */}
                {activeStep === 1 && (
                  <SelectPlan
                    templates={templates}
                    selectedTemplate={selectedTemplate}
                    setSelectedTemplate={setSelectedTemplate}
                  />
                )}

                {/* Step 2: Personal Information */}
                {activeStep === 2 && (
                  <PersonalInfo personalInfo={personalInfo} setPersonalInfo={setPersonalInfo} />
                )}

                {/* Step 3: Work Experience */}
                {activeStep === 3 && (
                  <WorkExperience
                    workExperience={workExperience}
                    handleRemoveWorkExperience={handleRemoveWorkExperience}
                    setWorkExperience={setWorkExperience}
                    handleAddWorkExperience={handleAddWorkExperience}
                  />
                )}

                {/* Step 4: Education (now a separate component) */}
                {activeStep === 4 && (
                  <EducationSection
                    education={education}
                    setEducation={setEducation}
                    handleAddEducation={handleAddEducation}
                    handleRemoveEducation={handleRemoveEducation}
                  />
                )}

                {/* Step 5: Skills & Languages (now a separate component) */}
                {activeStep === 5 && (
                  <SkillsAndLanguagesSection
                    skills={skills}
                    setSkills={setSkills}
                    handleAddSkill={handleAddSkill}
                    handleRemoveSkill={handleRemoveSkill}
                    languages={languages}
                    setLanguages={setLanguages}
                    handleAddLanguage={handleAddLanguage}
                    handleRemoveLanguage={handleRemoveLanguage}
                  />
                )}
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={handlePrevStep} disabled={activeStep === 1}>
                  Previous
                </Button>
                {activeStep < 5 ? (
                  <Button onClick={handleNextStep}>Next</Button>
                ) : (
                  <Button onClick={handleGenerateCV} disabled={isLoading} className="gap-2">
                    {isLoading ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Eye className="h-4 w-4" />
                        Generate CV
                      </>
                    )}
                  </Button>
                )}
              </CardFooter>
            </Card>
          </div>
          <div>
            {/* Tips & Suggestions (now a separate component) */}
            <TipsAndSuggestions activeStep={activeStep} />
          </div>
        </div>
      )}
    </div>
  );
}
