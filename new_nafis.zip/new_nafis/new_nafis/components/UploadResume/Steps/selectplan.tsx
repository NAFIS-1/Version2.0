import React from 'react'

interface Template {
  id: string;
  name: string;
  description: string;
  thumbnail?: string;
}

interface SelectPlanProps {
  templates: Template[];
  selectedTemplate: string;
  setSelectedTemplate: (id: string) => void;
}

function SelectPlan({templates, selectedTemplate, setSelectedTemplate}: SelectPlanProps) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {templates.map((template) => (
        <div
          key={template.id}
          className={`border rounded-lg p-3 cursor-pointer transition-all ${
            selectedTemplate === template.id
              ? "border-primary bg-primary/5" 
              : "hover:border-muted-foreground/50"
          }`}
          onClick={() => setSelectedTemplate(template.id)}
        >
          <div className="aspect-[3/4] mb-2 bg-muted rounded overflow-hidden">
            <img
              src={template.thumbnail || "/placeholder.svg"}
              alt={template.name}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="text-center">
            <h3 className="font-medium text-sm">{template.name}</h3>
            <p className="text-xs text-muted-foreground">{template.description}</p>
          </div>
        </div>
      ))}
    </div>
  )
}

export default SelectPlan
