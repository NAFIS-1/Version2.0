
import { useState } from "react"
import { Plus, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"

interface WorkExperience {
  id: string
  title: string
  company: string
  location: string
  startDate: string
  endDate: string
  current: boolean
  description: string
}

interface WorkExperienceProps {
  workExperience: any
  handleRemoveWorkExperience: (id: any) => void
  setWorkExperience: (experience: any) => void
  handleAddWorkExperience: () => void
}

function WorkExperience({
  workExperience,
  handleRemoveWorkExperience,
  setWorkExperience,
  handleAddWorkExperience
}: WorkExperienceProps) {
  return (
    <div className="space-y-6">
      {workExperience.map((exp, index) => (
        <div key={exp.id} className="border rounded-lg p-4">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-medium">Work Experience #{index + 1}</h3>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-destructive"
              onClick={() => handleRemoveWorkExperience(exp.id)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor={`job-title-${exp.id}`}>Job Title</Label>
                <Input
                  id={`job-title-${exp.id}`}
                  value={exp.title}
                  onChange={(e) => {
                    const updated = workExperience.map((item) =>
                      item.id === exp.id ? { ...item, title: e.target.value } : item
                    )
                    setWorkExperience(updated)
                  }}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor={`company-${exp.id}`}>Company</Label>
                <Input
                  id={`company-${exp.id}`}
                  value={exp.company}
                  onChange={(e) => {
                    const updated = workExperience.map((item) =>
                      item.id === exp.id ? { ...item, company: e.target.value } : item
                    )
                    setWorkExperience(updated)
                  }}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor={`location-${exp.id}`}>Location</Label>
              <Input
                id={`location-${exp.id}`}
                value={exp.location}
                onChange={(e) => {
                  const updated = workExperience.map((item) =>
                    item.id === exp.id ? { ...item, location: e.target.value } : item
                  )
                  setWorkExperience(updated)
                }}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor={`start-date-${exp.id}`}>Start Date</Label>
                <Input
                  id={`start-date-${exp.id}`}
                  type="month"
                  value={exp.startDate}
                  onChange={(e) => {
                    const updated = workExperience.map((item) =>
                      item.id === exp.id ? { ...item, startDate: e.target.value } : item
                    )
                    setWorkExperience(updated)
                  }}
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor={`end-date-${exp.id}`}>End Date</Label>
                  <div className="flex items-center space-x-2">
                    <Label htmlFor={`current-${exp.id}`} className="text-sm">
                      Current
                    </Label>
                    <Switch
                      id={`current-${exp.id}`}
                      checked={exp.current}
                      onCheckedChange={(checked) => {
                        const updated = workExperience.map((item) =>
                          item.id === exp.id ? { ...item, current: checked } : item
                        )
                        setWorkExperience(updated)
                      }}
                    />
                  </div>
                </div>
                <Input
                  id={`end-date-${exp.id}`}
                  type="month"
                  value={exp.endDate}
                  disabled={exp.current}
                  onChange={(e) => {
                    const updated = workExperience.map((item) =>
                      item.id === exp.id ? { ...item, endDate: e.target.value } : item
                    )
                    setWorkExperience(updated)
                  }}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor={`description-${exp.id}`}>Description</Label>
              <Textarea
                id={`description-${exp.id}`}
                rows={3}
                value={exp.description}
                onChange={(e) => {
                  const updated = workExperience.map((item) =>
                    item.id === exp.id ? { ...item, description: e.target.value } : item
                  )
                  setWorkExperience(updated)
                }}
              />
            </div>
          </div>
        </div>
      ))}
      <Button variant="outline" className="w-full gap-2" onClick={handleAddWorkExperience}>
        <Plus className="h-4 w-4" />
        Add Work Experience
      </Button>
    </div>
  )
}


export default WorkExperience
