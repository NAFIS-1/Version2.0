import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Save } from "lucide-react";
import { Separator } from "@/components/ui/separator";

interface TipsAndSuggestionsProps {
  activeStep: number;
}

const TipsAndSuggestions: React.FC<TipsAndSuggestionsProps> = ({ activeStep }) => {
  return (
    <Card className="sticky top-6">
      <CardHeader>
        <CardTitle>Tips & Suggestions</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {activeStep === 1 && (
          <div className="space-y-2">
            <p className="text-sm">
              <span className="font-medium">Professional Template:</span> Best for traditional industries like
              banking, finance, and government.
            </p>
            <p className="text-sm">
              <span className="font-medium">Modern Template:</span> Great for tech, marketing, and startups.
            </p>
            <p className="text-sm">
              <span className="font-medium">Executive Template:</span> Ideal for senior positions and leadership
              roles.
            </p>
            <p className="text-sm">
              <span className="font-medium">Creative Template:</span> Perfect for design, media, and creative
              industries.
            </p>
          </div>
        )}
        {activeStep === 2 && (
          <div className="space-y-2">
            <p className="text-sm">
              <span className="font-medium">Professional Title:</span> Be specific about your role and
              expertise.
            </p>
            <p className="text-sm">
              <span className="font-medium">Summary:</span> Keep it concise (3-5 sentences) and highlight your
              key strengths.
            </p>
            <p className="text-sm">
              <span className="font-medium">Contact Info:</span> Ensure your email and phone number are
              professional and up-to-date.
            </p>
          </div>
        )}
        {activeStep === 3 && (
          <div className="space-y-2">
            <p className="text-sm">
              <span className="font-medium">Work Experience:</span> List your experiences in reverse
              chronological order (most recent first).
            </p>
            <p className="text-sm">
              <span className="font-medium">Job Descriptions:</span> Use action verbs and quantify achievements
              when possible.
            </p>
            <p className="text-sm">
              <span className="font-medium">Relevance:</span> Focus on experiences most relevant to the job
              you're applying for.
            </p>
          </div>
        )}
        {activeStep === 4 && (
          <div className="space-y-2">
            <p className="text-sm">
              <span className="font-medium">Education:</span> Include relevant certifications and courses.
            </p>
            <p className="text-sm">
              <span className="font-medium">Recent Graduates:</span> Highlight academic achievements, projects,
              and relevant coursework.
            </p>
            <p className="text-sm">
              <span className="font-medium">Experienced Professionals:</span> Keep education brief unless
              directly relevant to the position.
            </p>
          </div>
        )}
        {activeStep === 5 && (
          <div className="space-y-2">
            <p className="text-sm">
              <span className="font-medium">Skills:</span> Include both technical and soft skills relevant to
              the job.
            </p>
            <p className="text-sm">
              <span className="font-medium">Languages:</span> Be honest about your proficiency level.
            </p>
            <p className="text-sm">
              <span className="font-medium">Prioritize:</span> List your strongest and most relevant skills
              first.
            </p>
          </div>
        )}
        <Separator />
        <div className="bg-blue-50 border border-blue-200 rounded p-3">
          <p className="text-xs text-blue-800">
            <span className="font-medium">AI Tip:</span> Your profile shows strong frontend development skills.
            Consider highlighting your React expertise and UI/UX experience prominently in your CV.
          </p>
        </div>
        <div className="bg-amber-50 border border-amber-200 rounded p-3">
          <p className="text-xs text-amber-800">
            <span className="font-medium">Note:</span> Autofilled using AI – Please verify all details before
            finalizing your CV.
          </p>
        </div>
      </CardContent>
      <CardFooter>
        <Button variant="outline" className="w-full gap-2">
          <Save className="h-4 w-4" />
          Save Draft
        </Button>
      </CardFooter>
    </Card>
  );
};

export default TipsAndSuggestions;
