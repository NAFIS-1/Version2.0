import React from 'react';
import { Check, Download, Eye, FileText, LinkIcon, Loader2, Plus, Save, Share2, Trash2, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";

import {
  Dialog,
  DialogContent, 
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface UploadCVProps {
  isLoading: boolean;
  onUploadStart: () => void;
  isPreviewMode: boolean;
  setIsPreviewMode: (value: boolean) => void;
  setdata: (value: any) => void;
}

function UploadCV({
  isLoading,
  onUploadStart,
  isPreviewMode,
  setIsPreviewMode,
  setdata
}: UploadCVProps) {
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = React.useState<string>('');
  const [open, setOpen] = React.useState(false);
  const [uploadedFile, setUploadedFile] = React.useState<string>('');
  const [selectedFile, setSelectedFile] = React.useState<File | null>(null);
  const [isAiLoading, setIsAiLoading] = React.useState(false);
  const { toast } = useToast();
  const [precessing,setprocessing]=React.useState(false);

  const handleBrowseClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
      setSelectedFile(file);
    }
  };

  const handleUploadAndProcess = async () => {
    setprocessing(true);
    if (!selectedFile) {
      toast({
        title: "Error",
        description: "Please select a file first",
        variant: "destructive",
      });
      return;
    }

    setOpen(false);
    onUploadStart();
    setIsAiLoading(true);

    const formData = new FormData();
    formData.append('file', selectedFile);

    try {
      const response = await fetch('http://127.0.0.1:8000/upload', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        const data = await response.json();
        setdata(data);
        setUploadedFile(selectedFile.name);

        toast({
          title: "Success",
          description: `Resume "${selectedFile.name}" uploaded and parsed successfully!`,
          variant: "default",
        });
      } else {
        const errorData = await response.json();
        console.error('Upload failed:', errorData);
        toast({
          title: "Upload Failed",
          description: errorData.detail || "Could not process your resume. Please try again.",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      console.error('Error uploading file:', error);
      toast({
        title: "Network Error",
        description: "Failed to connect to the server. Please check your internet connection.",
        variant: "destructive",
      });
    } finally {
      setIsAiLoading(false);
    }
  };

  return (
    <div className="flex gap-2">
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button variant="outline" className="gap-2">
            <Upload className="h-4 w-4" />
            {uploadedFile ? `Current: ${uploadedFile}` : precessing?'Ai is Reading Your Resume':'Upload Resume'}
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Upload Your Resume</DialogTitle>
            <DialogDescription>
              Upload your existing resume and our AI will automatically fill in your information.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            {isAiLoading ? (
              <div className="text-center p-8">
                <Loader2 className="h-8 w-8 mx-auto mb-2 animate-spin" />
                <p className="font-medium">AI is processing your resume...</p>
                <p className="text-sm text-muted-foreground">This may take a few moments</p>
              </div>
            ) : (
              <div
                className="border-2 border-dashed rounded-lg p-8 text-center cursor-pointer hover:bg-muted/50 transition-colors"
                onClick={handleBrowseClick}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  className="hidden"
                  accept=".pdf,.docx"
                  onChange={handleFileChange}
                />
                <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                {fileName ? (
                  <p className="font-medium mb-1">Selected file: {fileName}</p>
                ) : (
                  <p className="font-medium mb-1">Drag and drop your resume here</p>
                )}
                <p className="text-sm text-muted-foreground mb-4">Supports PDF, DOCX (max 5MB)</p>
                <Button size="sm" onClick={handleBrowseClick}>Browse Files</Button>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" className="gap-2" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button 
              className="gap-2" 
              disabled={isLoading || !selectedFile}
              onClick={handleUploadAndProcess}
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4" />
                  Upload & Process
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Button
        variant={isPreviewMode ? "default" : "outline"}
        className="gap-2"
        onClick={() => setIsPreviewMode(!isPreviewMode)}
      >
        <Eye className="h-4 w-4" />
        {isPreviewMode ? "Edit Mode" : "Preview"}
      </Button>
    </div>
  );
}

export default UploadCV;
