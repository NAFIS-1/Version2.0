import React from "react";
import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { SkillItem, LanguageItem } from "@/types/resume"; // Import interfaces

interface SkillsAndLanguagesSectionProps {
  skills: SkillItem[];
  setSkills: React.Dispatch<React.SetStateAction<SkillItem[]>>;
  handleAddSkill: () => void;
  handleRemoveSkill: (id: number) => void;
  languages: LanguageItem[];
  setLanguages: React.Dispatch<React.SetStateAction<LanguageItem[]>>;
  handleAddLanguage: () => void;
  handleRemoveLanguage: (id: number) => void;
}

const SkillsAndLanguagesSection: React.FC<SkillsAndLanguagesSectionProps> = ({
  skills,
  setSkills,
  handleAddSkill,
  handleRemoveSkill,
  languages,
  setLanguages,
  handleAddLanguage,
  handleRemoveLanguage,
}) => {
  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <h3 className="font-medium">Skills</h3>
        {skills.map((skill, index) => (
          <div key={skill.id} className="flex items-center gap-4">
            <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor={`skill-name-${skill.id}`}>Skill</Label>
                <Input
                  id={`skill-name-${skill.id}`}
                  value={skill.name}
                  onChange={(e) => {
                    const updated = skills.map((item) =>
                      item.id === skill.id ? { ...item, name: e.target.value } : item,
                    );
                    setSkills(updated);
                  }}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor={`skill-level-${skill.id}`}>Level</Label>
                <Select
                  value={skill.level}
                  onValueChange={(value) => {
                    const updated = skills.map((item) =>
                      item.id === skill.id ? { ...item, level: value as SkillItem['level'] } : item,
                    );
                    setSkills(updated);
                  }}
                >
                  <SelectTrigger id={`skill-level-${skill.id}`}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Beginner">Beginner</SelectItem>
                    <SelectItem value="Intermediate">Intermediate</SelectItem>
                    <SelectItem value="Advanced">Advanced</SelectItem>
                    <SelectItem value="Expert">Expert</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-destructive"
              onClick={() => handleRemoveSkill(skill.id)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        ))}
        <Button variant="outline" className="gap-2" onClick={handleAddSkill}>
          <Plus className="h-4 w-4" />
          Add Skill
        </Button>
      </div>

      <Separator />

      <div className="space-y-4">
        <h3 className="font-medium">Languages</h3>
        {languages.map((lang, index) => (
          <div key={lang.id} className="flex items-center gap-4">
            <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor={`lang-name-${lang.id}`}>Language</Label>
                <Input
                  id={`lang-name-${lang.id}`}
                  value={lang.name}
                  onChange={(e) => {
                    const updated = languages.map((item) =>
                      item.id === lang.id ? { ...item, name: e.target.value } : item,
                    );
                    setLanguages(updated);
                  }}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor={`lang-level-${lang.id}`}>Proficiency</Label>
                <Select
                  value={lang.level}
                  onValueChange={(value) => {
                    const updated = languages.map((item) =>
                      item.id === lang.id ? { ...item, level: value as LanguageItem['level'] } : item,
                    );
                    setLanguages(updated);
                  }}
                >
                  <SelectTrigger id={`lang-level-${lang.id}`}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Beginner">Beginner</SelectItem>
                    <SelectItem value="Intermediate">Intermediate</SelectItem>
                    <SelectItem value="Advanced">Advanced</SelectItem>
                    <SelectItem value="Fluent">Fluent</SelectItem>
                    <SelectItem value="Native">Native</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-destructive"
              onClick={() => handleRemoveLanguage(lang.id)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        ))}
        <Button variant="outline" className="gap-2" onClick={handleAddLanguage}>
          <Plus className="h-4 w-4" />
          Add Language
        </Button>
      </div>
    </div>
  );
};

export default SkillsAndLanguagesSection;
