
import { Key, ReactElement, ReactNode, JSXElementConstructor } from 'react'
import { Check, Download, Eye, FileText, LinkIcon, Loader2, Plus, Save, Share2, Trash2, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Switch } from "@/components/ui/switch"
import UploadCV from "@/components/UploadResume/Upload"
import ProgressTracker from "@/components/UploadResume/ProgressTracker"

interface PreviewResumeProps {
  personalInfo: {
    firstName: string;
    lastName: string;
    title: string;
    email: string;
    phone: string;
    location: string;
    summary: string;
  };
  workExperience: Array<{
    id: Key;
    title: string;
    company: string;
    startDate: string;
    current: boolean;
    endDate: string;
    location: string;
    description: string;
  }>;
  education: Array<{
    id: Key;
    degree: string;
    institution: string;
    startDate: string;
    endDate: string;
    location: string;
    description: string;
  }>;
  skills: Array<{
    id: Key;
    name: string;
    level: string;
  }>;
  languages: Array<{
    id: Key;
    name: string;
    level: string;
  }>;
  selectedTemplate: string;
  templates: Array<{
    id: Key;
    name: string;
  }>;
  setSelectedTemplate: (value: string) => void;
  setIsPreviewMode: (value: boolean) => void;
}

function PreviewResume({
  personalInfo,
  workExperience,
  education,
  skills,
  languages,
  selectedTemplate,
  templates,
  setSelectedTemplate,
  setIsPreviewMode
}: PreviewResumeProps) {
  return (
<div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>CV Preview</CardTitle>
                <CardDescription>This is how your CV will look</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg p-8 bg-white">
                  {/* CV Preview based on selected template */}
                  <div className="space-y-6">
                    {/* Header */}
                    <div className="text-center mb-6">
                      <h1 className="text-2xl font-bold mb-1">
                        {personalInfo.firstName} {personalInfo.lastName}
                      </h1>
                      <p className="text-lg text-muted-foreground mb-2">{personalInfo.title}</p>
                      <div className="flex flex-wrap justify-center gap-3 text-sm">
                        <span className="flex items-center gap-1">
                          <FileText className="h-3 w-3" />
                          {personalInfo.email}
                        </span>
                        <span className="flex items-center gap-1">
                          <FileText className="h-3 w-3" />
                          {personalInfo.phone}
                        </span>
                        <span className="flex items-center gap-1">
                          <FileText className="h-3 w-3" />
                          {personalInfo.location}
                        </span>
                      </div>
                    </div>

                    {/* Summary */}
                    <div>
                      <h2 className="text-lg font-semibold border-b pb-1 mb-2">Professional Summary</h2>
                      <p>{personalInfo.summary}</p>
                    </div>

                    {/* Work Experience */}
                    <div>
                      <h2 className="text-lg font-semibold border-b pb-1 mb-3">Work Experience</h2>
                      <div className="space-y-4">
                        {workExperience.map((exp: { id: Key | null | undefined; title: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode>  | Promise<string | number | bigint | boolean  | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined; company: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode>  | Promise<string | number | bigint | boolean |   ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined; startDate: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> |   Promise<string | number | bigint | boolean |   ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined; current: any; endDate: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> |   Promise<string | number | bigint | boolean |   ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined; location: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> |   Promise<string | number | bigint | boolean |   ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined; description: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> |   Promise<string | number | bigint | boolean |   ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined }) => (
                          <div key={exp.id}>
                            <div className="flex justify-between items-start">
                              <div>
                                <h3 className="font-medium">{exp.title}</h3>
                                <p className="text-muted-foreground">{exp.company}</p>
                              </div>
                              <div className="text-sm text-right">
                                <p>
                                  {exp.startDate} - {exp.current ? "Present" : exp.endDate}
                                </p>
                                <p className="text-muted-foreground">{exp.location}</p>
                              </div>
                            </div>
                            <p className="text-sm mt-2">{exp.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Education */}
                    <div>
                      <h2 className="text-lg font-semibold border-b pb-1 mb-3">Education</h2>
                      <div className="space-y-4">
                        {education.map((edu: { id: Key | null | undefined; degree: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> |   Promise<string | number | bigint | boolean |   ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined; institution: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> |   Promise<string | number | bigint | boolean |   ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined; startDate: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> |   Promise<string | number | bigint | boolean |   ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined; endDate: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> |   Promise<string | number | bigint | boolean |   ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined; location: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> |   Promise<string | number | bigint | boolean |   ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined; description: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> |   Promise<string | number | bigint | boolean |   ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined }) => (
                          <div key={edu.id}>
                            <div className="flex justify-between items-start">
                              <div>
                                <h3 className="font-medium">{edu.degree}</h3>
                                <p className="text-muted-foreground">{edu.institution}</p>
                              </div>
                              <div className="text-sm text-right">
                                <p>
                                  {edu.startDate} - {edu.endDate}
                                </p>
                                <p className="text-muted-foreground">{edu.location}</p>
                              </div>
                            </div>
                            <p className="text-sm mt-2">{edu.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Skills */}
                    <div>
                      <h2 className="text-lg font-semibold border-b pb-1 mb-3">Skills</h2>
                      <div className="flex flex-wrap gap-2">
                        {skills.map((skill: { id: Key | null | undefined; name: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> |   Promise<string | number | bigint | boolean |   ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined; level: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> |   Promise<string | number | bigint | boolean |   ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined }) => (
                          <Badge key={skill.id} variant="secondary">
                            {skill.name} ({skill.level})
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {/* Languages */}
                    <div>
                      <h2 className="text-lg font-semibold border-b pb-1 mb-3">Languages</h2>
                      <div className="flex flex-wrap gap-4">
                        {languages.map((lang: { id: Key | null | undefined; name: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> |   Promise<string | number | bigint | boolean |   ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined; level: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> |   Promise<string | number | bigint | boolean |   ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined }) => (
                          <div key={lang.id}>
                            <span className="font-medium">{lang.name}:</span> {lang.level}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={() => setIsPreviewMode(false)}>
                  Back to Edit
                </Button>
                <div className="flex gap-2">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" className="gap-2">
                        <Download className="h-4 w-4" />
                        Download
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <FileText className="h-4 w-4 mr-2" />
                        Download as PDF
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <FileText className="h-4 w-4 mr-2" />
                        Download as DOCX
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                  <Button className="gap-2">
                    <Share2 className="h-4 w-4" />
                    Share
                  </Button>
                </div>
              </CardFooter>
            </Card>
          </div>
          <div>
            <Card className="sticky top-6">
              <CardHeader>
                <CardTitle>CV Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Template</Label>
                  <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {templates.map((template: { id: Key | null | undefined; name: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> |   Promise<string | number | bigint | boolean |   ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined }) => (
                        <SelectItem key={template.id} value={template.id as string}>
                          {template.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Font</Label>
                  <Select defaultValue="inter">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="inter">Inter</SelectItem>
                      <SelectItem value="arial">Arial</SelectItem>
                      <SelectItem value="times">Times New Roman</SelectItem>
                      <SelectItem value="calibri">Calibri</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Color Scheme</Label>
                  <Select defaultValue="default">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="default">Default</SelectItem>
                      <SelectItem value="blue">Professional Blue</SelectItem>
                      <SelectItem value="green">Modern Green</SelectItem>
                      <SelectItem value="minimal">Minimal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Language</Label>
                  <Select defaultValue="en">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="ar">Arabic</SelectItem>
                      <SelectItem value="bilingual">Bilingual (Eng/Ar)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Separator />
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="show-photo">Show Photo</Label>
                    <Switch id="show-photo" />
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="show-links">Show Social Links</Label>
                    <Switch id="show-links" defaultChecked />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>  )
}

export default PreviewResume
