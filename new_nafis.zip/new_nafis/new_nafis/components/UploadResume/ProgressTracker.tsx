
import { Check, Download, Eye, FileText, LinkIcon, Loader2, Plus, Save, Share2, Trash2, Upload } from "lucide-react"

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

import { Progress } from "@/components/ui/progress"

interface ProgressTrackerProps {
  progress: number;
  activeStep: number;
}

const ProgressTracker: React.FC<ProgressTrackerProps> = ({ progress = 0, activeStep = 1 }) => {
  const normalizedProgress = Math.min(Math.max(progress, 0), 100);
  const steps = ["Template", "Personal", "Experience", "Education", "Skills"];

  return (
    <Card className="mb-6">
      <CardContent className="pt-6">
        <div className="space-y-4">
          <div className="flex justify-between text-sm">
            <span>Progress</span>
            <span>{normalizedProgress}%</span>
          </div>
          <Progress value={normalizedProgress} className="h-2" />
          <div className="flex justify-between">
            {steps.map((step, index) => (
              <div
                key={step}
                className={`flex flex-col items-center ${
                  activeStep > index + 1 
                    ? "text-primary" 
                    : activeStep === index + 1 
                      ? "text-primary font-medium" 
                      : "text-muted-foreground"
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 ${
                    activeStep > index + 1
                      ? "bg-primary text-primary-foreground"
                      : activeStep === index + 1
                        ? "border-2 border-primary text-primary"
                        : "border border-muted-foreground text-muted-foreground"
                  }`}
                >
                  {activeStep > index + 1 ? <Check className="h-4 w-4" /> : index + 1}
                </div>
                <span className="text-xs">{step}</span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProgressTracker;
