import React from "react";
import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { EducationItem } from "@/types/resume"; // Import the interface

interface EducationSectionProps {
  education: EducationItem[];
  setEducation: React.Dispatch<React.SetStateAction<EducationItem[]>>;
  handleAddEducation: () => void;
  handleRemoveEducation: (id: number) => void;
}

const EducationSection: React.FC<EducationSectionProps> = ({
  education,
  setEducation,
  handleAddEducation,
  handleRemoveEducation,
}) => {
  return (
    <div className="space-y-6">
      {education.map((edu, index) => (
        <div key={edu.id} className="border rounded-lg p-4">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-medium">Education #{index + 1}</h3>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-destructive"
              onClick={() => handleRemoveEducation(edu.id)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor={`degree-${edu.id}`}>Degree/Certificate</Label>
              <Input
                id={`degree-${edu.id}`}
                value={edu.degree}
                onChange={(e) => {
                  const updated = education.map((item) =>
                    item.id === edu.id ? { ...item, degree: e.target.value } : item,
                  );
                  setEducation(updated);
                }}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor={`institution-${edu.id}`}>Institution</Label>
              <Input
                id={`institution-${edu.id}`}
                value={edu.institution}
                onChange={(e) => {
                  const updated = education.map((item) =>
                    item.id === edu.id ? { ...item, institution: e.target.value } : item,
                  );
                  setEducation(updated);
                }}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor={`location-${edu.id}`}>Location</Label>
              <Input
                id={`location-${edu.id}`}
                value={edu.location}
                onChange={(e) => {
                  const updated = education.map((item) =>
                    item.id === edu.id ? { ...item, location: e.target.value } : item,
                  );
                  setEducation(updated);
                }}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor={`start-date-${edu.id}`}>Start Year</Label>
                <Input
                  id={`start-date-${edu.id}`}
                  value={edu.startDate}
                  onChange={(e) => {
                    const updated = education.map((item) =>
                      item.id === edu.id ? { ...item, startDate: e.target.value } : item,
                    );
                    setEducation(updated);
                  }}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor={`end-date-${edu.id}`}>End Year</Label>
                <Input
                  id={`end-date-${edu.id}`}
                  value={edu.endDate}
                  onChange={(e) => {
                    const updated = education.map((item) =>
                      item.id === edu.id ? { ...item, endDate: e.target.value } : item,
                    );
                    setEducation(updated);
                  }}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor={`description-${edu.id}`}>Description</Label>
              <Textarea
                id={`description-${edu.id}`}
                rows={3}
                value={edu.description}
                onChange={(e) => {
                  const updated = education.map((item) =>
                    item.id === edu.id ? { ...item, description: e.target.value } : item,
                  );
                  setEducation(updated);
                }}
              />
            </div>
          </div>
        </div>
      ))}
      <Button variant="outline" className="w-full gap-2" onClick={handleAddEducation}>
        <Plus className="h-4 w-4" />
        Add Education
      </Button>
    </div>
  );
};

export default EducationSection;
